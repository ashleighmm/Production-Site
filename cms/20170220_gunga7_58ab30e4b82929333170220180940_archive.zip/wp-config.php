<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'gungatveyr_dbmain');

/** MySQL database username */
define('DB_USER', 'gungatveyr_4');

/** MySQL database password */
define('DB_PASSWORD', 'EbBkpCcT8H8');

/** MySQL hostname */
define('DB_HOST', 'sql25.jnb1.host-h.net');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8'); 

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'q0lr&[GgK(+,olT4vwq>-H<-;l?,6bHbR6g|Pc^|t|Q#Q(2g8Ucxv+Wz-A}qlk-e');
define('SECURE_AUTH_KEY',  '>S?9cUQg}5#^c]Mm-^~Pz_K_t-N+6-w|4n`S=wH!lS)hqBB>eyEbn3fe#R-}E1B/');
define('LOGGED_IN_KEY',    '/VTRHjhwJ&%EHyym[B^@tD_L?BuU)cl))k)ktSAL4xfCa^UI+O@F:g#Ts1x)eE^s');
define('NONCE_KEY',        'nz,8n7y?8U2!+C*|5>:5ZUSv2y@[/6*N*%FqM|N?6W#|PM(N*w/En-GTi?0kbz,)');
define('AUTH_SALT',        'zS7Sm-|[[$!!w[;>F2nO+dTi}t*N}9>YaW|;un817=1NH{rx+AK[-Z/}n5%.!gG&');
define('SECURE_AUTH_SALT', 'Nl2CpT^ZF|u.#L2_h>3P9S:e|?rWkv6daWa=L`1{nq&-(C,M klc@0(Xy&:$FOZI');
define('LOGGED_IN_SALT',   '/Z}~De/P8Y)HuNwlZ4Cmn8M]A7in$qEwK|>o&],<KkNsg3!JTH~a|X>GsF;N w_6');
define('NONCE_SALT',       'Y;s:I~|cR,-1|0r(;s~b#Q:}?i.53kKr.q>6k)un$K*er5x&7M1z S7 .v5WX|/I');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
